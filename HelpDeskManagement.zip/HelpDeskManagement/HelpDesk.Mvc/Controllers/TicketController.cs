﻿using HelpDesk.Api.Models;
using HelpDesk.Mvc.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace HelpDesk.Mvc.Controllers
{
    public class TicketController : Controller
    {
        private readonly ITicketService _ticketService;
        public TicketController(ITicketService ticketService)
        {
            _ticketService = ticketService;
        }
        public async Task<IActionResult> Dashboard()
        {
            var tickets = await _ticketService.GetAllTicketsAsync();
            ViewBag.TotalTickets = tickets.Count;
            ViewBag.OpenTickets = tickets.Count(t => t.Status == "Open");
            ViewBag.ClosedTickets = tickets.Count(t => t.Status == "Closed");
            return View();
        }
        public async Task<IActionResult> Index()
        {
            var tickets = await _ticketService.GetAllTicketsAsync();
            return View(tickets);
        }
        public async Task<IActionResult> Details(int id)
        {
            var ticket = await _ticketService.GetTicketByIdAsync(id);
            if (ticket == null || ticket.Id == 0) return NotFound();
            return View(ticket);
        }
        public IActionResult Create()
        {
            ViewBag.Priorities = new SelectList(new[] { "Low", "Medium", "High" });
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Create(Ticket ticket)
        {
            ticket.Status = "Open";
            ticket.CreatedDate = DateTime.Now;

            await _ticketService.CreateTicketAsync(ticket);
            return RedirectToAction(nameof(Index));
        }
        public async Task<IActionResult> Edit(int id)
        {
            var ticket = await _ticketService.GetTicketByIdAsync(id);
            if (ticket == null || ticket.Id == 0) return NotFound();

            ViewBag.Priorities = new SelectList(new[] { "Low", "Medium", "High" });
            ViewBag.Statuses = new SelectList(new[] { "Open", "In Progress", "Closed" });
            return View(ticket);
        }
        [HttpPost]
        public async Task<IActionResult> Edit(Ticket ticket)
        {
            await _ticketService.UpdateTicketAsync(ticket);
            return RedirectToAction(nameof(Index));
        }
        public async Task<IActionResult> Delete(int id)
        {
            var ticket = await _ticketService.GetTicketByIdAsync(id);
            if (ticket == null || ticket.Id == 0) return NotFound();
            return View(ticket);
        }
        [HttpPost, ActionName("Delete")]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            await _ticketService.DeleteTicketAsync(id);
            return RedirectToAction(nameof(Index));
        }
        public async Task<IActionResult> Filter(string status)
        {
            ViewBag.Statuses = new SelectList(new[] { "Open", "In Progress", "Closed" });
            var tickets = new List<Ticket>();
            if (!string.IsNullOrEmpty(status))
            {
                tickets = await _ticketService.GetTicketsByStatusAsync(status);
            }
            return View(tickets);
        }
    }
}